using System.DirectoryServices;

namespace PRELAB_CARLOSARGUETA_VC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string user = "Usuario";
            string password = "Chomin";

            if(textBox1.Text == user && textBox2.Text== password)
            {
                MessageBox.Show("Welcome" + user);
                Form2 v2 = new Form2();
                v2.Show();
            }
            else
            {
                MessageBox.Show("Incorrect password or user");
            }
        }
    }
}
